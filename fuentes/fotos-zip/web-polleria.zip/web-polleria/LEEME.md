# [MARCA] — Web pollo a la brasa

Set de 32 imágenes + landing page. Dirección visual: **brasa criolla premium**
(base negra, brasa naranja, paleta peruana: ají amarillo, huacatay, rocoto).

---

## 1. Qué cambiar antes de publicar (3 cosas)

| # | Dónde | Qué |
|---|-------|-----|
| 1 | `main.js` → objeto `CONFIG` | WhatsApp, teléfono, dirección, horario, Instagram |
| 2 | `index.html` | Reemplazar `[MARCA]` (nav, hero, footer, `<title>`, Open Graph) |
| 3 | `index.html` | **Los precios son referenciales** (mercado Lima 2026). Poner los tuyos |

El WhatsApp va en formato internacional sin `+` ni espacios: `51987654321`.
Cada botón de plato ya lleva su mensaje precargado (`data-msg`).
Para el mapa: pegar el `<iframe>` de Google Maps dentro del `div#mapa`.

---

## 2. Cómo cambiar una foto por otra

Todas las fotos están en `assets/images/web/`. Para cambiar una, edita el
`src` en `index.html`. Ejemplo — cambiar la opción del 1/4 pecho:

```html
<img src="assets/images/web/pecho-op-d.webp" ...>
                              ↑ cambia por pecho-op-a / -b / -c
```

### Opciones listas para intercambiar

**1/4 pecho** (4 posiciones distintas — puesta: `pecho-op-d`)

| Archivo | Toma |
|---|---|
| `pecho-op-a` | Pecho parado con el ala levantada, ángulo bajo, brasas al fondo |
| `pecho-op-b` | Cenital, plato dividido en tres |
| `pecho-op-c` | Perfil a nivel del ojo, minimalista |
| `pecho-op-d` | **Fileteado en abanico** — se ve la carne blanca |

**1/2 pollo** (puesta: `medio-op-a`)

| Archivo | Toma |
|---|---|
| `medio-op-a` | **3/4, la media res completa y conectada** |
| `medio-op-b` | Cenital, silueta inconfundible de medio pollo |
| `medio-op-c` | Parada, se ve el corte con la carne blanca y el hueso |

---

## 3. Carta armada

**El pollo** — todos con papas y ensalada incluidas

| Plato | Imagen | Ref. |
|---|---|---|
| 1/4 pierna | `cuarto-pierna` | S/ 24.90 |
| 1/4 pecho | `pecho-op-d` | S/ 24.90 |
| 1/2 pollo | `medio-op-a` | S/ 42.90 |
| Pollo entero | `pollo-entero` | S/ 79.90 |

**Combos**

| Plato | Imagen | Ref. |
|---|---|---|
| Combo personal (1/4 + papas + ensalada + chicha) | `combo-personal` | S/ 29.90 |
| Combo familiar (entero + papas + ensalada + jarra 1 L) | `combo-familiar` | S/ 94.90 |
| Para llevar | `delivery-caja` | mismo precio |

**A la parrilla / con arroz**

| Plato | Imagen | Ref. |
|---|---|---|
| Anticucho (2 palos) | `anticuchos` | S/ 29.90 |
| 1/4 con arroz | `combo-arroz` | S/ 27.90 |

**Guarniciones**

| Plato | Imagen | Ref. |
|---|---|---|
| Papas de la casa | `papas` | S/ 12.90 |
| Ensalada fresca | `ensalada` | S/ 12.90 |
| Arroz graneado | `arroz` | S/ 8.90 |
| Tequeños (8 u.) | `tequenos-queso` | S/ 18.90 |

**Para tomar**

| Plato | Imagen | Ref. |
|---|---|---|
| Chicha morada · vaso | `chicha-vaso` | S/ 7.90 |
| Chicha morada · jarra 1 L | `chicha-jarra` | S/ 18.90 |

**Ambiente y secciones**

| Uso | Imagen |
|---|---|
| Hero escritorio | `hero-brasa` (16:9, espacio negativo a la izquierda) |
| Hero celular | `hero-vertical` (9:16, entra solo bajo 700 px) |
| Banner "La brasa" | `horno-brasas` |
| Bloque "Las cremas" | `cremas` |
| Banner "Para la mesa" | `mesa-completa` |
| Dónde estamos | `fachada-noche` |

---

## 4. Repuestos (no están en la web, listas para redes o carta física)

`local-ambiente` (salón de noche) · `aderezo-ingredientes` (ají panca, sillao,
comino, ajo, huacatay, romero) · `anticucho-parrilla` (anticuchos sobre la
brasa) · `pollo-tabla` (pollo recién salido del horno con el cuchillo) ·
`entero-cenital` · `pierna-cenital` · `chicha-banner` (16:9 con espacio para
titular) · `detalle-brasa` (macro de la piel) · `tequenos` · `medio-pollo` y
`cuarto-pecho` (las primeras versiones).

---

## 5. Archivos

```
index.html                    página completa
styles.css                    todo el diseño (variables CSS arriba del archivo)
main.js                       CONFIG + nav + WhatsApp + animaciones
assets/images/*.png           originales de Higgsfield (2336×1744 / 2688×1520)
assets/images/web/*.webp      versiones optimizadas — LAS QUE USA LA PÁGINA
assets/images/web/*.jpg       mismas imágenes en JPG (respaldo / redes / delivery)
```

Peso real de la web: ~3.5 MB, porque solo carga las 21 fotos que usa.

---

## 6. Cómo se generaron las imágenes

- Modelo: **GPT Image 2** (Higgsfield MCP), 2k / calidad alta
- 32 generaciones en total
- Bloque de estilo fijo en todos los prompts, para que el set se vea de la
  misma marca. Si quieres más tomas, copia esto y cambia solo el plato:

> *Deep charcoal background with a soft out-of-focus orange ember glow and thin
> drifting smoke, dark textured slate surface, warm directional key light from
> upper left, deep controlled shadows. Shot on 85mm at f/2.8, ultra realistic
> crisp texture, appetizing, premium Peruvian restaurant menu photography.
> No text, no lettering, no watermark, no logo, no hands, no people.*

Dos aprendizajes de esta tanda, por si generas más:

1. Para el pollo hay que describir la **anatomía** explícitamente. "Medio
   pollo" solo funciona diciendo *"a SINGLE UNBROKEN PIECE where breast, wing,
   thigh and drumstick are all still joined"*; si no, el modelo dibuja piezas
   sueltas.
2. Para el 1/4 pecho hay que **prohibir** la pierna: *"no drumstick, no thigh,
   no leg anywhere in the image"*.

---

## 7. Pendientes

- [ ] Video de fondo del hero (Seedance 2.0) — el `<img>` actual sirve de poster
- [ ] Logo / wordmark real reemplazando `[MARCA]`
- [ ] Libro de Reclamaciones (obligatorio en Perú — INDECOPI)
- [ ] Fotos reales del local cuando abra
