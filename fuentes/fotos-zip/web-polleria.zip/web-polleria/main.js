/* ============================================================
   [MARCA] — main.js
   ▼▼▼ LO ÚNICO QUE TIENES QUE EDITAR ESTÁ AQUÍ ABAJO ▼▼▼
   ============================================================ */

const CONFIG = {
  marca:     "[MARCA]",
  // Número de WhatsApp en formato internacional, SIN + ni espacios.
  // Perú = 51. Ejemplo: 51987654321
  whatsapp:  "51999999999",
  telefono:  "+51 999 999 999",
  direccion: "Av. Ejemplo 123, Santiago de Surco, Lima",
  horario:   "Lun a Dom · 12:00 – 23:00",
  instagram: "https://instagram.com/tu_cuenta",
  // Mensaje por defecto cuando el cliente escribe desde un botón sin plato asignado
  msgDefault: "Hola, quiero hacer un pedido"
};

/* ============================================================
   De aquí para abajo no hace falta tocar nada.
   ============================================================ */

(function () {
  'use strict';

  /* ---------- 1. Rellenar datos del CONFIG ---------- */
  document.querySelectorAll('[data-cfg]').forEach(function (el) {
    var k = el.getAttribute('data-cfg');
    if (CONFIG[k]) el.textContent = CONFIG[k];
  });

  document.querySelectorAll('[data-cfg-href]').forEach(function (el) {
    var k = el.getAttribute('data-cfg-href');
    if (CONFIG[k]) { el.href = CONFIG[k]; el.target = '_blank'; el.rel = 'noopener'; }
  });

  /* ---------- 2. Enlaces de WhatsApp ---------- */
  document.querySelectorAll('[data-wa]').forEach(function (el) {
    var msg = el.getAttribute('data-msg') || CONFIG.msgDefault;
    el.href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(msg);
    el.target = '_blank';
    el.rel = 'noopener';
  });

  /* ---------- 3. Nav sticky + menú móvil ---------- */
  var nav = document.getElementById('nav');
  var toggle = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');
  var fab = document.getElementById('fab');

  function onScroll() {
    var y = window.scrollY;
    nav.classList.toggle('stuck', y > 40);
    if (fab) fab.classList.toggle('on', y > window.innerHeight * 0.75);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      nav.classList.add('stuck');
    });
    links.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') {
        links.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- 4. Animaciones de entrada ----------
     Solo se activan si el navegador las soporta y el usuario no pidió
     "menos movimiento". Si no, la página se ve completa desde el inicio. */
  var items = document.querySelectorAll('.reveal');
  var quieto = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if ('IntersectionObserver' in window && !quieto) {
    document.documentElement.classList.add('js-anim');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add('in'); });
  }

  /* Hero: entra apenas carga */
  if (!quieto) requestAnimationFrame(function () {
    document.querySelectorAll('.rise').forEach(function (el, i) {
      el.style.transition = 'opacity .9s cubic-bezier(.2,.7,.3,1) ' + (i * .1) + 's, transform .9s cubic-bezier(.2,.7,.3,1) ' + (i * .1) + 's';
      el.style.opacity = 0;
      el.style.transform = 'translateY(24px)';
      requestAnimationFrame(function () {
        el.style.opacity = 1;
        el.style.transform = 'none';
      });
    });
  });

  /* ---------- 5. Parallax suave del hero ---------- */
  var heroImg = document.querySelector('.hero-media img');
  if (heroImg && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        var y = Math.min(window.scrollY, window.innerHeight);
        heroImg.style.transform = 'translate3d(0,' + (y * 0.18) + 'px,0) scale(1.06)';
        ticking = false;
      });
    }, { passive: true });
  }

})();
